import java.awt.*;
import java.applet.*;
/* <applet code="Checkboxdemo.class" width="200" height="200">
</applet>
*/
public class Checkboxdemo extends Applet
	{
		public void init()
			{
			Checkbox C1=new Checkbox();
			//C1.add("java");
			//C1.add("php");
			//C1.add("lap");
			add(C1);//display for the output
			}
			}
			
			